export function applyScaleDefaults(defaults: any): void;
