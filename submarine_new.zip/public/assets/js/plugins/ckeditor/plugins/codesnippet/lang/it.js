/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","it",{button:"Inserisci frammento di codice",codeContents:"Contenuto del codice",emptySnippetError:"Un frammento di codice non può essere vuoto.",language:"Lingua",title:"Frammento di codice",pathName:"frammento di codice"});